document.addEventListener('DOMContentLoaded', function() {
    // Change header background on scroll
    window.addEventListener('scroll', function() {
        const header = document.querySelector('header');
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // Initialize AOS library
    AOS.init({
        duration: 1000, // Animation duration in ms
        easing: 'ease-in-out', // Animation easing
        once: true // Animate only once
    });

    document.getElementById('contact-form').addEventListener('submit', function(event) {
        event.preventDefault();

        alert('Merci pour votre message ! Nous reviendrons vers vous bientôt.');

        // Réinitialiser le formulaire
        this.reset();
    });
});

// Toggle the navigation menu on mobile
// function toggleMenu() {
//     const menuToggle = document.querySelector('.menu-toggle');
//     const nav = document.querySelector('nav');
//     menuToggle.classList.toggle('active');
//     nav.classList.toggle('active');
// }
// document.addEventListener('DOMContentLoaded', function() {
//     AOS.init(); // Initialisation d'AOS

//     document.getElementById('contact-form').addEventListener('submit', function(event) {
//         event.preventDefault();

//         alert('Merci pour votre message ! Nous reviendrons vers vous bientôt.');

//         // Réinitialiser le formulaire
//         this.reset();
//     });
// });


function toggleMenu() {
    var nav = document.getElementById('main-nav');
    nav.classList.toggle('active');
}

function openModal(memberId) {
    var modal = document.getElementById('modal');
    var modalImage = document.getElementById('modal-image');
    var modalName = document.getElementById('modal-name');
    var modalDescription = document.getElementById('modal-description');

    // Contenu des membres
    var members = {
        member1: {
            name: 'Abdou Aziz Seck',
            description: "Je suis un développeur passionné par la création d'applications mobiles et web. Mon intérêt pour l'intelligence artificielle est particulièrement marqué, et je suis constamment en quête de nouvelles connaissances et d'opportunités pour améliorer mes compétences. Mon objectif est de concevoir des projets innovants qui génèrent un impact positif tout en poursuivant mon développement professionnel. Je m'efforce de rester à la pointe des technologies et de m'engager dans des apprentissages continus pour offrir des solutions qui répondent aux besoins actuels et futurs.",
            image: 'seck.jpg'
        },
        member2: {
            name: 'Moussa Ndiaye',
            description: "Je me présente comme un passionné des nouvelles technologies, un véritable enthousiaste de la robotique, qui nourrit une profonde admiration pour l’espace, les mangas et tout ce qui touche à cet univers. C’est dans cette dynamique d’exploration et de découverte que j’ai plongé dans le monde fascinant de l’informatique, et plus particulièrement dans le codage. Au fil des années, j’ai consacré beaucoup de temps et d’efforts à perfectionner mes compétences dans ce domaine. Mon parcours m’a conduit à me spécialiser dans le développement de sites web et d’applications multiplateformes. Aujourd’hui, je me dirige avec une grande motivation vers un nouveau défi : la cybersécurité, un domaine en perpétuelle évolution qui suscite un vif intérêt et enthousiasme chez moi.",
            image: 'moussa.jpg'
        },
        member3: {
            name: 'Samba Seydi',
            description: "Je suis un jeune développeur fullstack avec une passion inébranlable pour le codage, que ce soit de jour ou de nuit. À court terme, mon objectif est de devenir le meilleur créateur de plateformes 3D dans mon pays avant de commencer l'université. À moyen terme, je vise à me positionner parmi les meilleurs hackers, avec un désir constant de perfectionner mes compétences. À long terme, je souhaite continuer à profiter pleinement du plaisir de coder, toujours en quête de nouveaux défis et d'innovations. Ce site a été conçu pour renforcer la visibilité, à la fois pour moi et pour mes amis tout aussi passionnés. Si vous avez un projet à nous confier ou à l'un d'entre nous en particulier, soyez assurés que nous nous en occuperons avec le plus grand soin et un engagement total.",
            image: 'samba.jpg'
        }
    };

    var member = members[memberId];

    modalImage.src = member.image;
    modalName.textContent = member.name;
    modalDescription.textContent = member.description;

    modal.style.display = 'flex';
}

function closeModal() {
    var modal = document.getElementById('modal');
    modal.style.display = 'none';
}
